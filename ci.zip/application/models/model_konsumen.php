<?php 
class Model_konsumen extends ci_model{

	public function tampil_list_data(){
			$query="select * from tbl_konsumen";
			return $this->db->query($query);
	}
	public function tampil_list_data_agama(){
			$query="select * from tbl_agama";
			return $this->db->query($query);
	}
	public function view_list_data(){
			$query="select * from tampil_agama";
			return $this->db->query($query);
	}
	public function input_data($data){
		$this->db->insert('tbl_konsumen',$data);
	}
	public function ambil_data($id_konsumen){
		$data = array('id_konsumen'=>$id_konsumen);
		return $this->db->get_where('tampil_agama',$data);
	}
	function edit_data($data,$id_konsumen)
    {
        $this->db->where('id_konsumen',$id_konsumen);
        $this->db->update('tbl_konsumen',$data);
    }
	function hapus_data($id_konsumen)
    {
        $this->db->where('id_konsumen',$id_konsumen);
        $this->db->delete('tbl_konsumen');
    }

}