<?php 
class Model_agama extends ci_model{

	public function tampil_list_data_agama(){
			$query="select * from tbl_agama";
			return $this->db->query($query);
	}
	public function input_data($data){
		$this->db->insert('tbl_agama',$data);
	}
	public function ambil_data($id_agama){
		$data = array('id_agama'=>$id_agama);
		return $this->db->get_where('tbl_agama',$data);
	}
	function edit_data($data,$id_agama)
    {
        $this->db->where('id_agama',$id_agama);
        $this->db->update('tbl_agama',$data);
    }
	function hapus_data($id_agama)
    {
        $this->db->where('id_agama',$id_agama);
        $this->db->delete('tbl_agama');
    }

}