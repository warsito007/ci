<?php
class Model_user extends CI_Model{

  function get_kategori(){
    $Proses=$this->db->get('agama');
    return $Proses;
  }
  function get_all_user() {
        $this->db->select(',id_user,nama_user,id_agama,agama');
        $this->db->from('user');
        $this->db->join('agama', 'agama_user=id_agama');
  }

}
