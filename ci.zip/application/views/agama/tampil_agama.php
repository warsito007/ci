<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Data Agama</h4>
                <div class="table-responsive m-t-40">
                    <a href="<?php echo base_url();?>agama/tambah_data";>
                        <button type="button" class="btn btn-rounded btn-success"> <!-- buat bentuk dan warna bg-->
                            <span class="ti-plus"<!-- buat simbul tombol-></span> Tambah
                        </button>
                    </a>
                    <table id="tabel_tanpa" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <td>No</td>
                                <td>Name</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; foreach ($tampil_data_agama->result() as $tampil){?>
                            <tr>
                                <td><?php $no;?></td>
                                <td><?php echo $tampil->agama;?></td>
                                <td>
                                    <a href="<?php echo base_url();?>agama/edit_data/<?php echo $tampil->id_agama;?>";>
                                        <button type="button" class="btn btn-rounded btn-info"> <!-- buat bentuk dan warna bg-->
                                            <span class="ti-plus"></span>Edit Data
                                        </button>
                                    </a>
                                    
                                    || 
                                    <a href="<?php echo base_url();?>agama/hapus_data/<?php echo $tampil->id_agama;?>" onclick="return confirm('Yakin Mau Hapus?');">
                                        <button type="button" class="btn btn-rounded btn-danger"> <!-- buat bentuk dan warna bg-->
                                            <span class="ti-plus"></span>Hapus Data
                                        </button>
                                    </a>
                                </td>
                            </tr>
                            <?php $no++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>