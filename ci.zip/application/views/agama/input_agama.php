<?php 
echo form_open('agama/tambah_data');?>
<table class="table table-bordered">
	<tr>
		<td>Nama Agama</td>
		<td><input type="text" name="agama"/></td>
	</tr>
	<tr>
		<td></td>
		<td> <button type="submit" class="btn btn-primary btn-sm" name="save">Simpan</button></td>

	</tr>
</table>
