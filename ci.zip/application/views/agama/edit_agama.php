<?php 
echo form_open('agama/edit_agama');?>
<table class="table table-bordered">
	<tr>
		<td>Nama konsumen</td>
		<td><input type="text" name="agama" value="<?php echo $data_edit['agama'];?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td> <button type="submit" class="btn btn-primary btn-sm" name="save">Simpan</button></td>
		<input type="hidden" name="id_agama" value="<?php echo $data_edit['id_agama'];?>"/>
	</tr>
</table>