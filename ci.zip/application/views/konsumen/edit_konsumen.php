<?php 
echo form_open('konsumen/edit_data');?>
<table class="table table-bordered">
	<tr>
		<td>Nama konsumen</td>
		<td><input type="text" name="nama_konsumen" value="<?php echo $data_edit['nama_konsumen'];?>"/></td>
	</tr>
	<tr>
		<td>Agama</td>
		<td>
			<select name="id_agama" value="<?php echo $data_edit['agama'];?>" class="form-list" required> 
			    <option value="<?php echo $data_edit['id_agama'];?>"><?php echo $data_edit['agama'];?></option>
                <option>Pilih Data</option>
                <?php foreach ($data_edit->result() as $tampil){?> 
				<option value='<?php echo $tampil->id_agama;?>'><?php echo $tampil->agama;?></option>
				<?php } ?>
        	</select>
    	</td>
	</tr>
	<tr>
		<td></td>
		<td> <button type="submit" class="btn btn-primary btn-sm" name="save">Simpan</button></td>
		<input type="hidden" name="id_konsumen" value="<?php echo $data_edit['id_konsumen'];?>"/>
	</tr>
</table>
