<?php echo form_open('konsumen/tambah_data');?>
<table class="table table-bordered">
	<tr>
		<td>Nama konsumen</td>
		<td><input type="text" name="nama_konsumen"/></td>
	</tr>
	<tr>
		<td>Agama</td>
	<td>
		<select name="id_agama" value="" class="form-list" required> 
            <option>Pilih Agama</option>
            <?php foreach ($tampil_data_konsumen->result() as $tampil){?> 
			<option value='<?php echo $tampil->id_agama;?>'><?php echo $tampil->agama;?></option>
			<?php } ?>
        </select>
        <a class="has-arrow waves-effect waves-dark" href="<?php echo base_url();?>konsumen/input_konsumen" aria-expanded="false">
            <i class="mdi mdi-plus"></i>
            <span class="hide-menu">Tambah Agama</span>
        </a>
    </td>
	</tr>
	<tr>
		<td></td>
		<td> <button type="submit" class="btn btn-primary btn-sm" name="save">Simpan</button></td>

	</tr>
</table>
