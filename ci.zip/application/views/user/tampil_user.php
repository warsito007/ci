<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Data Konsumen</h4>
                <div class="table-responsive m-t-40">
                    <a href="<?php echo base_url();?>user/tambah_data";>
                        <button type="button" class="btn btn-rounded btn-success"> <!-- buat bentuk dan warna bg-->
                            <span class="ti-plus"<!-- buat simbul tombol-></span> Tambah
                        </button>
                    </a>
                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <td>Name</td>
                                <td>Agama</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; foreach ($tampil_data_barang->result() as $tampil){?>
                            <tr>
                                <td><?php echo $tampil->nama_user;?></td>
                                <td><?php echo $tampil->agama;?></td>
                                <td>
                                    <a href="<?php echo base_url();?>user/edit_data/<?php echo $tampil->id_user;?>";>
                                        <button type="button" class="btn btn-rounded btn-info"> <!-- buat bentuk dan warna bg-->
                                            <span class="ti-plus"></span>Edit Data
                                        </button>
                                    </a>
                                    
                                    || 
                                    <a href="<?php echo base_url();?>user/hapus_data/<?php echo $tampil->id_user;?>" onclick="return confirm('Yakin Mau Hapus?');">
                                        <button type="button" class="btn btn-rounded btn-danger"> <!-- buat bentuk dan warna bg-->
                                            <span class="ti-plus"></span>Hapus Data
                                        </button>
                                    </a>
                                </td>
                            </tr>
                            <?php $no++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>