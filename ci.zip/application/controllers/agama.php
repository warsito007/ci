<?php
class Agama extends CI_Controller{
    
function __construct() {
    parent::__construct();
	$this->load->model('model_agama');
	$this->load->helper('form');
}		

public function index() {
    $data['tampil_data_agama'] = $this->model_agama->tampil_list_data_agama();
    $this->load->view('design/header');
    $this->load->view('agama/tampil_agama',$data);
	$this->load->view('design/footer');
}
public function tambah_data(){
	if(isset($_POST['save'])){
	$agama = $this->input->post('agama');
	$data=array(
			'agama' =>$agama
			);
			$this->model_agama->input_data($data);
			redirect('konsumen/tambah_data');
	}else{
	$this->load->view('design/header');
	$this->load->view('agama/input_agama');
	$this->load->view('design/footer');
        
    }
}
public function edit_data(){			
		if(isset($_POST['save'])){
			$id_agama = $this->input->post('id_agama');
			$agama = $this->input->post('agama');
	        $data=array(
	    		'id_agama'=>$id_agama,
				'agama' =>$agama,
				);
				$this->model_agama->edit_data($data,$id_agama);
				redirect('agama');
		}else{
		$id_agama=$this->uri->segment(3);
		$data['data_edit'] = $this->model_agama->ambil_data($id_agama)->row_array();
    	$this->load->view('design/header');
		$this->load->view('agama/edit_agama',$data);
		$this->load->view('design/footer');
			
		}
}
public function hapus_data()
{
    $id_agama=  $this->uri->segment(3);
    $this->model_agama->hapus_data($id_agama);
    redirect('agama');
}
  
}