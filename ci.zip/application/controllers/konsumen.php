<?php
class Konsumen extends CI_Controller{
    
function __construct() {
    parent::__construct();
	$this->load->model('model_konsumen');
	$this->load->helper('form');
}		

public function index() {
  	$data['tampil_data_barang'] = $this->model_konsumen->view_list_data();
    $this->load->view('design/header');
    $this->load->view('konsumen/tampil_konsumen',$data);
	$this->load->view('design/footer');
}
public function tambah_data(){
	$data_tampil_konsumen['tampil_data_konsumen'] = $this->model_konsumen->tampil_list_data_agama();
	if(isset($_POST['save'])){
	$nama_konsumen = $this->input->post('nama_konsumen');
	$id_agama = $this->input->post('id_agama');
	$data=array(
			'nama_konsumen' =>$nama_konsumen,
			'id_agama'=>$id_agama
			);
			$this->model_konsumen->input_data($data);
			redirect('konsumen');
	}else{
	$this->load->view('design/header');
	$this->load->view('konsumen/input_konsumen',$data_tampil_konsumen);
	$this->load->view('design/footer');
        
    }
}
public function edit_data(){		
	if(isset($_POST['save'])){
		$id_konsumen = $this->input->post('id_konsumen');
		$nama_konsumen = $this->input->post('nama_konsumen');
		$id_agama = $this->input->post('id_agama');
        $data=array(
    		'id_konsumen'=>$id_konsumen,
			'nama_konsumen' =>$nama_konsumen,
			'id_agama'=>$id_agama
			);
			$this->model_konsumen->edit_data($data,$id_konsumen);
			redirect('konsumen');
		}
	}else{
	$id_konsumen=$this->uri->segment(3);
	$data['data_edit'] = $this->model_konsumen->ambil_data($id_konsumen)->row_array();
	$this->load->view('design/header');
	$this->load->view('konsumen/edit_konsumen',$data);
	$this->load->view('design/footer');
	}
public function hapus_data()
{
    $id_konsumen=  $this->uri->segment(3);
    $this->model_konsumen->hapus_data($id_konsumen);
    redirect('konsumen');
}
  
}